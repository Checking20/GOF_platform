var common = {
    'username':"",//当前登录的用户
    'workInterfaceMapId':"", //在分享界面点击作品的mapId
}